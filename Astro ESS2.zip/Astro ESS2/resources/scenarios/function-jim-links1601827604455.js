(function(window, undefined) {

  var jimLinks = {
    "bec95322-54a5-4b26-adc1-b02197bad84d" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ]
    },
    "59243cb6-0e46-4bad-a79a-1bcd89cb2b77" : {
      "Rectangle_1" : [
        "56d0b172-5c7a-4353-b730-18d745bd6de3"
      ],
      "Image_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "2a896fe2-7d65-43ec-b246-37dadb485236" : {
      "Rectangle_1" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ],
      "Image_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a0ca790c-1873-449b-b937-dc2635744cad" : {
      "Image_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_5" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ],
      "Rectangle_6" : [
        "56d0b172-5c7a-4353-b730-18d745bd6de3"
      ],
      "Rectangle_7" : [
        "56d0b172-5c7a-4353-b730-18d745bd6de3"
      ],
      "Rectangle_8" : [
        "4e1c5ee4-8185-439d-81a6-b0cd2aae070a"
      ]
    },
    "4e1c5ee4-8185-439d-81a6-b0cd2aae070a" : {
      "Rectangle_1" : [
        "a0ca790c-1873-449b-b937-dc2635744cad"
      ],
      "Image_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "329a0e4c-d15c-4627-be00-143988951c59" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ]
    },
    "0c260bb9-ae4f-454b-81cf-294aed4c6ca2" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "bec95322-54a5-4b26-adc1-b02197bad84d"
      ]
    },
    "22a61aba-2c04-4f99-9930-6ddccfe5560b" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_1" : [
        "4bfee3e3-9dff-410c-ab25-7d4d54059f7e"
      ],
      "Rectangle_2" : [
        "f3791bb2-fc37-48a9-894b-cbbc4d291e17"
      ],
      "Rectangle_3" : [
        "329a0e4c-d15c-4627-be00-143988951c59"
      ],
      "Rectangle_6" : [
        "0c260bb9-ae4f-454b-81cf-294aed4c6ca2"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_1" : [
        "a0ca790c-1873-449b-b937-dc2635744cad"
      ],
      "Rectangle_2" : [
        "2a896fe2-7d65-43ec-b246-37dadb485236"
      ]
    },
    "4bfee3e3-9dff-410c-ab25-7d4d54059f7e" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ]
    },
    "56d0b172-5c7a-4353-b730-18d745bd6de3" : {
      "Image_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_5" : [
        "a0ca790c-1873-449b-b937-dc2635744cad"
      ],
      "Rectangle_6" : [
        "59243cb6-0e46-4bad-a79a-1bcd89cb2b77"
      ]
    },
    "f3791bb2-fc37-48a9-894b-cbbc4d291e17" : {
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "22a61aba-2c04-4f99-9930-6ddccfe5560b"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);