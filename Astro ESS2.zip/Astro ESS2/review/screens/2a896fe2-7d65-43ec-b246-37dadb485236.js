var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-2a896fe2-7d65-43ec-b246-37dadb485236" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Reconocimineto facial 2" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2a896fe2-7d65-43ec-b246-37dadb485236-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/2a896fe2-7d65-43ec-b246-37dadb485236-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/2a896fe2-7d65-43ec-b246-37dadb485236-1601827604455-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="622.0px" datasizeheight="563.0px" dataX="329.0" dataY="69.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b2e5a5c0-831d-4b6e-8213-405a16ae75d8.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_3"   datasizewidth="162.0px" datasizeheight="45.0px" datasizewidthpx="162.0" datasizeheightpx="45.0" dataX="560.0" dataY="691.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Ready</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="Image 3"   datasizewidth="200.0px" datasizeheight="200.0px" dataX="27.0" dataY="-24.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/37ec7b09-008f-4fbc-80e3-26e408e6896d.png" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;