var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-0c260bb9-ae4f-454b-81cf-294aed4c6ca2" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Datos diarios" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/0c260bb9-ae4f-454b-81cf-294aed4c6ca2-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/0c260bb9-ae4f-454b-81cf-294aed4c6ca2-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/0c260bb9-ae4f-454b-81cf-294aed4c6ca2-1601827604455-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 3"   datasizewidth="200.0px" datasizeheight="200.0px" dataX="17.0" dataY="-34.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/37ec7b09-008f-4fbc-80e3-26e408e6896d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="517.0px" datasizeheight="123.0px" datasizewidthpx="517.0" datasizeheightpx="123.0" dataX="381.0" dataY="43.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Daily data</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="250.0px" datasizeheight="45.0px" datasizewidthpx="250.0" datasizeheightpx="45.0" dataX="514.5" dataY="638.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Enter</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="281.0px" datasizeheight="46.0px" datasizewidthpx="281.00000000000006" datasizeheightpx="46.000000000000114" dataX="117.0" dataY="203.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"> &nbsp;How did you sleep?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="281.0px" datasizeheight="49.0px" datasizewidthpx="281.00000000000006" datasizeheightpx="49.0" dataX="117.0" dataY="482.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"> &nbsp;What problems did you &nbsp; have?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="281.0px" datasizeheight="46.0px" datasizewidthpx="281.00000000000006" datasizeheightpx="46.000000000000114" dataX="821.0" dataY="482.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"> &nbsp;How was the training?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="281.0px" datasizeheight="46.0px" datasizewidthpx="281.00000000000006" datasizeheightpx="46.000000000000114" dataX="821.0" dataY="203.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"> &nbsp;How was the food?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;