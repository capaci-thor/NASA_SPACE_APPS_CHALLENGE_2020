var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-22a61aba-2c04-4f99-9930-6ddccfe5560b" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Plan" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/22a61aba-2c04-4f99-9930-6ddccfe5560b-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/22a61aba-2c04-4f99-9930-6ddccfe5560b-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/22a61aba-2c04-4f99-9930-6ddccfe5560b-1601827604455-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 3"   datasizewidth="200.0px" datasizeheight="200.0px" dataX="17.0" dataY="-34.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/37ec7b09-008f-4fbc-80e3-26e408e6896d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="283.0px" datasizeheight="48.0px" datasizewidthpx="283.00000000000006" datasizeheightpx="48.000000000000114" dataX="828.0" dataY="470.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"> &nbsp;Training</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="283.0px" datasizeheight="48.0px" datasizewidthpx="283.00000000000006" datasizeheightpx="48.000000000000114" dataX="117.0" dataY="199.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"> &nbsp;Sleep </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="283.0px" datasizeheight="48.0px" datasizewidthpx="283.00000000000006" datasizeheightpx="48.000000000000114" dataX="828.0" dataY="199.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"> &nbsp;Food</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Bullets-list" datasizewidth="218.0px" datasizeheight="203.0px" >\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="196.0px" datasizeheight="43.0px" dataX="170.5" dataY="290.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Sleep 8 Hours</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="184.0px" datasizeheight="43.0px" dataX="170.5" dataY="336.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="148.5" dataY="297.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="148.5" dataY="342.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="148.5" dataY="388.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_3)">\
                            <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_3" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_3_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="148.5" dataY="433.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_4)">\
                            <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_4" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_4_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_5" customid="Ellipse_5" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="148.5" dataY="479.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_5)">\
                            <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_5" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_5" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_5_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Bullets-list" datasizewidth="218.0px" datasizeheight="203.0px" >\
        <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="196.0px" datasizeheight="43.0px" dataX="881.0" dataY="258.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Next Meal</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_6" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="265.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_6)">\
                            <ellipse id="s-Ellipse_6" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_6" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_6_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_7" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="310.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_7)">\
                            <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_7" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_7_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_8" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="356.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_8)">\
                            <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_8" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_8_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_9" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="401.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_9)">\
                            <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_9" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_9_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_10" customid="Ellipse_5" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="447.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_10)">\
                            <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_5" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_10" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_10_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Bullets-list" datasizewidth="218.0px" datasizeheight="203.0px" >\
        <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="196.0px" datasizeheight="43.0px" dataX="881.0" dataY="541.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Short Workout</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_11" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="548.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_11)">\
                            <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_11" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_11_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_12" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="593.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_12)">\
                            <ellipse id="s-Ellipse_12" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_12" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_12_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_13" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_13 non-processed"   datasizewidth="10.0px" datasizeheight="10.0px" datasizewidthpx="10.0" datasizeheightpx="10.0" dataX="859.0" dataY="639.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_13" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_13)">\
                            <ellipse id="s-Ellipse_13" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_13" class="clipPath">\
                            <ellipse cx="5.0" cy="5.0" rx="5.0" ry="5.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_13" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_13_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Dropdown" datasizewidth="345.0px" datasizeheight="226.0px" >\
        <div id="s-Group_5" class="group firer ie-background commentable hidden non-processed" customid="Options" datasizewidth="345.0px" datasizeheight="181.0px" >\
          <div id="s-Rectangle_4" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle_2"   datasizewidth="343.0px" datasizeheight="44.0px" datasizewidthpx="343.0" datasizeheightpx="44.0" dataX="467.0" dataY="64.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_4_0">My plan person 1</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_5" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle_3"   datasizewidth="343.0px" datasizeheight="44.0px" datasizewidthpx="343.0" datasizeheightpx="44.0" dataX="467.0" dataY="109.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_5_0">My plan person 2</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input_1" class="pie text firer click ie-background commentable non-processed" customid="Input_1"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="467.0" dataY="19.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="My plan"/></div></div>  </div></div></div>\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="arrow"   datasizewidth="19.0px" datasizeheight="10.0px" dataX="773.0" dataY="37.0"   alt="image" systemName="./images/1b48f82f-2698-4a05-b12f-5f357fc4a424.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Image_2-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="s-Image_2-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
            	            <g id="s-Image_2-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_2-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="250.0px" datasizeheight="45.0px" datasizewidthpx="250.0" datasizeheightpx="45.0" dataX="514.5" dataY="640.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Enter daily data</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;