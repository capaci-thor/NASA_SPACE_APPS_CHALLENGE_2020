var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-56d0b172-5c7a-4353-b730-18d745bd6de3" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Personas extra" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/56d0b172-5c7a-4353-b730-18d745bd6de3-1601827604455.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/56d0b172-5c7a-4353-b730-18d745bd6de3-1601827604455-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/56d0b172-5c7a-4353-b730-18d745bd6de3-1601827604455-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="517.0px" datasizeheight="123.0px" datasizewidthpx="517.0" datasizeheightpx="123.0" dataX="380.5" dataY="17.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Please enter the following extra information</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="117.0" dataY="208.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Name"/></div></div>  </div></div></div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Counter-field" datasizewidth="64.0px" datasizeheight="46.0px" >\
        <div id="s-Input_2" class="pie text firer commentable non-processed" customid="counter"  datasizewidth="64.0px" datasizeheight="46.0px" dataX="398.0" dataY="431.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="1" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
        <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image_3"   datasizewidth="13.0px" datasizeheight="8.0px" dataX="440.0" dataY="461.0"   alt="image" systemName="./images/47b49f72-3783-4a5f-80fa-f7cdf325d73e.svg" overlay="#777777">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-Image_1-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-Image_1-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#777777 !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="Image_4"   datasizewidth="13.0px" datasizeheight="8.0px" dataX="440.0" dataY="440.0"  rotationdeg="180" alt="image" systemName="./images/4f6a1351-274f-4255-8f93-d5357828ae83.svg" overlay="#777777">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-Image_2-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-Image_2-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_2-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#777777 !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="281.0px" datasizeheight="46.0px" datasizewidthpx="281.00000000000006" datasizeheightpx="46.000000000000114" dataX="117.0" dataY="431.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"> &nbsp;Age</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed" customid="Image 3"   datasizewidth="200.0px" datasizeheight="200.0px" dataX="17.0" dataY="-34.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/37ec7b09-008f-4fbc-80e3-26e408e6896d.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Dropdown" datasizewidth="345.0px" datasizeheight="226.0px" >\
        <div id="s-Group_3" class="group firer ie-background commentable hidden non-processed" customid="Options" datasizewidth="345.0px" datasizeheight="181.0px" >\
          <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="792.0" dataY="253.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_3_0">Female</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_4" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_3"   datasizewidth="345.0px" datasizeheight="46.0px" datasizewidthpx="345.0" datasizeheightpx="46.0" dataX="792.0" dataY="298.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_4_0">Male</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input_3" class="pie text firer click commentable non-processed" customid="Input_1"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="792.0" dataY="208.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="Gender"/></div></div>  </div></div></div>\
\
        <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed" customid="arrow"   datasizewidth="19.0px" datasizeheight="10.0px" dataX="1098.0" dataY="226.0"   alt="image" systemName="./images/179ef725-be97-4fe9-afbc-7d4a9bb250bc.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Image_4-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="s-Image_4-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
            	            <g id="s-Image_4-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-Image_4-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="338.5px" datasizeheight="71.0px" datasizewidthpx="338.4999999999998" datasizeheightpx="71.0" dataX="470.0" dataY="637.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Ready</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="339.0px" datasizeheight="40.0px" datasizewidthpx="339.0" datasizeheightpx="40.0" dataX="795.0" dataY="434.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"> &nbsp;Facial recognition</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;